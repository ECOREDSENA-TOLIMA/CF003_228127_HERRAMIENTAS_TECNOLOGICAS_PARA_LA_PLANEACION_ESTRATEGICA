module.exports = 'Marco de referencia Arquitectura Empresarial'
